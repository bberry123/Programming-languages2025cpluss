#include "investment_calculator.h"

int main() {
    InvestmentCalculator calculator;
    calculator.run();

    return 0;
}

