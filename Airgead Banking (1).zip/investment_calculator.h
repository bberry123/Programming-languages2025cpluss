#ifndef AIRGEAD_INVESTMENT_CALCULATOR_H_
#define AIRGEAD_INVESTMENT_CALCULATOR_H_

#include <iostream>
#include <iomanip>
#include <string>

class InvestmentCalculator {
public:
    // Entry point to begin program interaction
    void run();

private:
    // Private member variables (note the m_ prefix)
    double m_initialInvestment;
    double m_monthlyDeposit;
    double m_annualInterest;
    int m_years;

    // Methods to interact with the user
    void getUserInput();
    void displayReportHeader(const std::string& t_title);
    void displayReportWithoutDeposits() const;
    void displayReportWithDeposits() const;

    // Helper method to calculate interest for a single month
    double calculateMonthlyInterest(double t_balance) const;
};

#endif  // AIRGEAD_INVESTMENT_CALCULATOR_H_
