#include "investment_calculator.h"

void InvestmentCalculator::run() {
    char continueInput = 'Y';

    do {
        getUserInput();

        std::cout << "\nPress Enter to display reports...";
        std::cin.ignore();
        std::cin.get();

        displayReportWithoutDeposits();
        displayReportWithDeposits();

        std::cout << "\nWould you like to run another simulation? (Y/N): ";
        std::cin >> continueInput;
        continueInput = toupper(continueInput);

    } while (continueInput == 'Y');
}

void InvestmentCalculator::getUserInput() {
    std::cout << "==============================\n";
    std::cout << "  Airgead Banking Calculator\n";
    std::cout << "==============================\n\n";

    std::cout << "Enter Initial Investment Amount: $";
    std::cin >> m_initialInvestment;

    std::cout << "Enter Monthly Deposit: $";
    std::cin >> m_monthlyDeposit;

    std::cout << "Enter Annual Interest Rate (e.g., 5 for 5%): ";
    std::cin >> m_annualInterest;

    std::cout << "Enter Number of Years: ";
    std::cin >> m_years;
}

void InvestmentCalculator::displayReportHeader(const std::string& t_title) {
    std::cout << "\n=============================================\n";
    std::cout << "  " << t_title << "\n";
    std::cout << "=============================================\n";
    std::cout << std::setw(6) << "Year"
        << std::setw(20) << "Year-End Balance"
        << std::setw(26) << "Year-End Earned Interest" << "\n";
    std::cout << "---------------------------------------------\n";
}

void InvestmentCalculator::displayReportWithoutDeposits() const {
    double yearEndBalance = m_initialInvestment;
    double monthlyRate = (m_annualInterest / 100) / 12;

    displayReportHeader("Balance and Interest Without Monthly Deposits");

    for (int year = 1; year <= m_years; ++year) {
        double interestEarned = 0.0;

        for (int month = 0; month < 12; ++month) {
            double interest = yearEndBalance * monthlyRate;
            interestEarned += interest;
            yearEndBalance += interest;
        }

        std::cout << std::setw(6) << year
            << std::setw(20) << std::fixed << std::setprecision(2) << yearEndBalance
            << std::setw(26) << interestEarned << "\n";
    }
}

void InvestmentCalculator::displayReportWithDeposits() const {
    double yearEndBalance = m_initialInvestment;
    double monthlyRate = (m_annualInterest / 100) / 12;

    displayReportHeader("Balance and Interest With Monthly Deposits");

    for (int year = 1; year <= m_years; ++year) {
        double interestEarned = 0.0;

        for (int month = 0; month < 12; ++month) {
            yearEndBalance += m_monthlyDeposit;
            double interest = yearEndBalance * monthlyRate;
            interestEarned += interest;
            yearEndBalance += interest;
        }

        std::cout << std::setw(6) << year
            << std::setw(20) << std::fixed << std::setprecision(2) << yearEndBalance
            << std::setw(26) << interestEarned << "\n";
    }
}

